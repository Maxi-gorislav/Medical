<?php

global $_MODULE;
$_MODULE = array();
