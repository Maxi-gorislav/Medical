# module PrestaBlog

## About

A module to add a blog on your web store.

## Contributing

H.D.Clic Copyright (c) permanent

## Requirements

Require PrestaShop e-commerce solution.
